## Assignment 1

**Libraries**
The first packages to be installed are the following image processing and arrays libraries:
* [matplotlib](https://matplotlib.org/)
* [imageio](https://imageio.readthedocs.io/en/stable/)
* [numpy](https://numpy.org/)

**Pre-work** for the coding session:
- Install jupyter notebook in miniconda environment as described above
- Install the above libraries using `pip` in the `ece352_env` environment
- Creation of the first notebook and familiarization with the logic of the cells, saving and loading of the notebook through the online manual

**ToDO**:
- As we processed the image "scarlett.jpg" with the transform $s = T(z) = 255 - z$, you will use the transformations below
	- $s = T(z) = log_{2}(1+z)$, you will display in plot format (as we saw in the lesson) the values ​​of $s$ with respect to $z$ and you will normalize them with the following formula: $scale = {L / (log_{2}(1+L))}$ where $L$ in our case is the maximum brightness value, i.e. 255. After normalization you will display a new plot with the new $s,z$ values.

	- $s = T(z) = L * (z / L) ^ g$, where $g=[0.1, 0.5, 1.2, 2.2]$ and $L$ in our case is the maximum brightness value, i.e. 255. You will display in plot format (as we saw in the lesson) the values ​​of $s$ with respect to $z$.

	- [Sigmoid function](https://en.wikipedia.org/wiki/Sigmoid_function), you will display in plot form (as we saw in the lesson) the values ​​of $s$ with respect to $z$.

- In both cases you will display the original and processed image in the form of subplots as we saw in the lesson. You can use "scarlett.jpg" or any other image you like.