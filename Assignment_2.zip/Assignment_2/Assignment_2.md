## Assignment 2

** To complete the second assignment:
- Create a function image_conv that will take as arguments an image $f$ and a filter $w$ and perform convolution between $f$ and $w$.
  - Initially $f$ will be a 5x5 image with random integers from the interval $[0,9]$, while the filter will be the following 3x3:
  
    [[0.125, 0.25,  0.], [0.125, 0.5,   0.], [0.,    0.,    0.]]
  
  - Create a padding function that will take as an argument the NxN image and return (N+2)x(N+2) image with zeros in the new positions of the table (zero padding)

  - Perform convolution between $f$ and $w$ after $f$ passes through padding and after flipping the filter in both dimensions.

- Using the above functions (image_conv and padding) perform a convolution between the image "gradient_noise.png" located in the "images" folder and an averaging filter with dimensions 3x3 and values ​​$1 \over 9$.